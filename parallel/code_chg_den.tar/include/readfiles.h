#ifndef READFILES_H
#define READFILES_H

#include "STRUCTURES.h"
// #include "fitting.h"
// #include "initialization.h"

void read_input(InputFile_Obj *fInput_Obj, main_Obj *ffmain_common_Obj);

#endif 